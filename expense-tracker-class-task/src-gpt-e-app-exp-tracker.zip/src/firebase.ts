import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyDo_n2EYT5xToJdj19pd72VK10M0gADetM",
  authDomain: "practice-firebase-814b5.firebaseapp.com",
  projectId: "practice-firebase-814b5",
  storageBucket: "practice-firebase-814b5.appspot.com",
  messagingSenderId: "327269264653",
  appId: "1:327269264653:web:7dcd40232f4ad427711444",
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
