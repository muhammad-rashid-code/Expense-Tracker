// src/app/charts/page.tsx
"use client";

import React from "react";
// import Charts from "../components/Charts";
import Charts from "../../components/Charts";
import NavBar from "../../components/NavBar";

const ChartsPage: React.FC = () => {
  return (
    <>
      <NavBar />
      <Charts expenses={[]} /> {/* Pass expenses as needed */}
    </>
  );
};

export default ChartsPage;
