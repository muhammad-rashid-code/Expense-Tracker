// Example for app/page.tsx
"use client";

import React from "react";
import Auth from "../components/Auth";
import NavBar from "../components/NavBar";

const Home: React.FC = () => {
    return (
        <>
            <NavBar />
            <Auth />
        </>
    );
};

export default Home;
