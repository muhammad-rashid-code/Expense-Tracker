// src/app/add-expense/page.tsx
"use client";

import React from "react";
// import ExpenseManager from "../components/ExpenseManager";
import ExpenseManager from "../../components/ExpenseManager";
import NavBar from "../../components/NavBar";

const AddExpensePage: React.FC = () => {
  return (
    <>
      <NavBar />
      <ExpenseManager />
    </>
  );
};

export default AddExpensePage;
