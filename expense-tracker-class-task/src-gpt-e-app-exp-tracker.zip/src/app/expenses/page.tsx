// src/app/expenses/page.tsx
"use client";

import React from "react";
// import ExpenseList from "../components/ExpenseList";
import ExpenseList from "../../components/ExpenseList";
import NavBar from "../../components/NavBar";

const ExpensesPage: React.FC = () => {
  return (
    <>
      <NavBar />
      <ExpenseList />
    </>
  );
};

export default ExpensesPage;
