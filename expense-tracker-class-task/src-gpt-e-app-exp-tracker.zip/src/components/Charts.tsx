// src/app/components/Charts.tsx
"use client";

import React from "react";
import { Pie, Bar } from "react-chartjs-2";
import { Chart as ChartJS, CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend, ArcElement } from "chart.js";

// Register Chart.js components
ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend, ArcElement);

const Charts: React.FC<{ expenses: any[] }> = ({ expenses }) => {
    const categories = ["Food", "Transport", "Bills", "Education", "Investments", "Luxuries", "Other"];
    const categoryTotals = categories.reduce((acc, category) => {
        acc[category] = expenses.filter(exp => exp.category === category).reduce((sum, exp) => sum + exp.amount, 0);
        return acc;
    }, {} as Record<string, number>);

    const pieData = {
        labels: Object.keys(categoryTotals),
        datasets: [{
            data: Object.values(categoryTotals),
            backgroundColor: ["#FF6384", "#36A2EB", "#FFCE56", "#FF6384", "#36A2EB", "#FFCE56", "#FF6384"],
        }],
    };

    const barData = {
        labels: expenses.map(exp => new Date(exp.date).toLocaleDateString()), // Adapt as needed
        datasets: [{
            label: 'Expenses',
            data: expenses.map(exp => exp.amount),
            backgroundColor: 'rgba(75, 192, 192, 0.6)',
        }],
    };

    return (
        <div>
            <h2>Expense Charts</h2>
            <Pie data={pieData} />
            <Bar data={barData} />
        </div>
    );
};

export default Charts;
