// src/app/components/NavBar.tsx
"use client";

import React from "react";
import Link from "next/link";
import { auth } from "../firebase";

const NavBar: React.FC = () => {
  const handleLogout = async () => {
    await auth.signOut();
  };

  return (
    <nav>
      <Link href="/">Home</Link>
      <br />
      <br />
      <Link href="/expenses">Expenses</Link>
      <br />
      <br />
      <Link href="/add-expense">Add Expense</Link>
      <br />
      <br />
      <Link href="/charts">Charts</Link>
      <br />
      <br />
      <button onClick={handleLogout}>Logout</button>
    </nav>
  );
};

export default NavBar;
