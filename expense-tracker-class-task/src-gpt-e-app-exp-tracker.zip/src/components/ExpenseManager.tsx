// src/app/components/ExpenseManager.tsx
"use client";

import React, { useState } from "react";
import { db } from "../firebase";
import { collection, addDoc } from "firebase/firestore";
import { useAuth } from "../hooks/useAuth";

const ExpenseManager: React.FC = () => {
  const { user } = useAuth();
  const [title, setTitle] = useState("");
  const [amount, setAmount] = useState(0);
  const [category, setCategory] = useState("");
  const [note, setNote] = useState("");

  const handleAddExpense = async (e: React.FormEvent) => {
    e.preventDefault();
    if (user) {
      await addDoc(collection(db, "expenses"), {
        userId: user.uid,
        title,
        amount,
        category,
        date: new Date().toISOString(),
        note,
      });
      // Reset form
      setTitle("");
      setAmount(0);
      setCategory("");
      setNote("");
    }
  };

  return (
    <form onSubmit={handleAddExpense}>
      <input
        type="text"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        placeholder="Title"
        required
      />
      <input
        type="number"
        value={amount}
        onChange={(e) => setAmount(Number(e.target.value))}
        placeholder="Amount"
        required
      />
      <select
        value={category}
        onChange={(e) => setCategory(e.target.value)}
        required
      >
        <option value="">Select Category</option>
        <option value="Food">Food</option>
        <option value="Transport">Transport</option>
        <option value="Bills">Bills</option>
        <option value="Education">Education</option>
        <option value="Investments">Investments</option>
        <option value="Luxuries">Luxuries</option>
        <option value="Other">Other</option>
      </select>
      <textarea
        value={note}
        onChange={(e) => setNote(e.target.value)}
        placeholder="Optional Note"
      ></textarea>
      <button type="submit">Add Expense</button>
    </form>
  );
};

export default ExpenseManager;
